from Student import *
from Instructor import Instructor
from method import *



class Admin(object):

    @staticmethod
    def addInstructor():
        iname=input("name of the instructor : ")
        igender = input("Gender : ")
        danceStyle = input(" dance style : ")
        contact = input("contact no : ")
        Rate = input(" hour rate : ")
        availability=list()
        print("Enter days available : (press 1 to end)")
        while(True):
            day=input(" input day : ")
            if(day=='1'):
                break
            availability.append(day)
        addInstructor(Instructor(iname,igender,danceStyle,contact,Rate,availability))


    @staticmethod
    def editInstructor():
        iname = input("Input instructor name want to change : ")
        igender = input("Changing Gender : ")
        danceStyle = input("Changing dance style : ")
        contact = input("Changing contact no : ")
        Rate = input("Changing hour rate : ")
        availability = list()
        # assume here you are unable to edit available dates
        changeInstructor(Instructor(iname, igender, danceStyle, contact, Rate, availability))

    @staticmethod
    def deleteInstructor():
        iname=input("input name of instructor want to remove :")
        deleteInstructor(iname)


    @staticmethod
    def viewInstructors():
        viewAllInstructors();

    @staticmethod
    def scheduleInstructor():
        insNme=input("Enter instructor name : ")
        setInstructorToStudents(insNme)

    @staticmethod
    def registerStudent():
        stid= input("Enter a student id : ")
        firstNm = input("Enter student first name : ")
        surNm = input("Enter  student Last name : ")
        emil = input("Enter student email : ")
        gender = input("Enter Gender : ")
        dob = input("Enter student birth day : ")
        pNo = input("Enter student contact no : ")
        addrss = input("Enter student address : ")
        danceStyle = input("Enter dance style : ")
        maxHrRate = input("Enter Maximum hour rate : ")
        addStudent(Student(stid,firstNm,surNm,emil,gender,dob,pNo,addrss,danceStyle,maxHrRate))

