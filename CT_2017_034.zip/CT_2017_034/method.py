import sqlite3
from tkinter import *

con=sqlite3.connect("assignment_db1.db")


def addInstructor(instructor):
    query="insert into Instructor values(?,?,?,?,?)"
    cursor=con.cursor()
    list1=(instructor.name,instructor.gender,instructor.styles,instructor.tpNo,instructor.hrRate)
    cursor.execute(query,list1)
    con.commit()
    for days in instructor.availability:
        query = "insert into Instructor_Availability values(?,?)"
        cursor = con.cursor()
        ls = (instructor.name, days)
        cursor.execute(query, ls)
        con.commit()
    print("done")


def addStudent(student):
    query = "insert into Student values(?,?,?,?,?,?,?,?,?,?,?)"
    cursor = con.cursor()
    ls = (student.stId,student.firstName, student.surName, student.email, student.gender, student.DoB,student.tpNo,student.address,student.danceStyle,student.maxHrRate,"")
    cursor.execute(query, ls)
    con.commit()
    print("done")


def changeInstructor(instructor):
    query = "update Instructor set Gender=?,style=?,Tp_No=?,HrRate=? where Name=?"
    cursor = con.cursor()
    ls = (instructor.gender, instructor.styles, instructor.tpNo, instructor.hrRate,instructor.name)
    cursor.execute(query, ls)
    con.commit()
    print("done")

def deleteInstructor(instructor):
    query = "delete from Instructor where Name=?"
    cursor = con.cursor()
    ls = (instructor,)
    cursor.execute(query, ls)
    con.commit()
    print("done")

def viewAllInstructors():
    query = "select * from Instructor"
    cursor = con.cursor()

    cursor.execute(query)
    rows=cursor.fetchall()
    root=Tk()
    rowCount=len(rows)
    colCount=len(rows[0])
    for i in range(rowCount):
        for j in range(colCount):
            enty=Label(root,width=20)
            enty.grid(row=i, column=j)
            enty['text'] = rows[i][j]


    print("done")

def setInstructorToStudents(nme):#get student ids of students and set instructor to them

    query1="select Student_ID,Style,MaxHrRate from Student"
    cursor = con.cursor()

    cursor.execute(query1)
    stuRows = cursor.fetchall()
    query2 = "select Style,HrRate from Instructor where Name='"+nme+"'"
    cursor = con.cursor()

    cursor.execute(query2)
    instructor = cursor.fetchall()
    setStudents=list()
    if(len(instructor)==0):
        print("No such instructor in db")
    else:
        for student in stuRows:
            #check instructors dancing style equals to student dancind method and students hr rate >= instructor hr rate
            if student[1]==instructor[0][0] and student[2]>=instructor[0][1]: #assume that we cannot have multiple instructor with same name
                setStudents.append(student[0])

        for stID in setStudents:

            query3="update Student set Name=? where Student_ID=?"
            cursor = con.cursor()
            ls = (nme,stID)
            cursor.execute(query3, ls)
            con.commit()
            print("done")




def isInsinDB(insNm):
    query = "select * from Instructor where Name='"+insNm+"'"
    cursor = con.cursor()

    cursor.execute(query)
    rows = cursor.fetchall()
    if(len(rows)==0):
        return False
    return rows


def addAbooking(insNme,bookingNo):
    query="select Student_ID from student where Name='"+insNme+"'"
    cursor = con.cursor()

    cursor.execute(query)
    stuRows = cursor.fetchall()
    for stNo in stuRows:
        query1 = "insert into Booking values(?,?,?)"
        cursor = con.cursor()
        stNo=stNo[0]
        ls = (stNo,insNme,bookingNo)
        cursor.execute(query1, ls)
        con.commit()
    print("done")



