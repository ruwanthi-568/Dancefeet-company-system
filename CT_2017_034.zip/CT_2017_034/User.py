from tkinter import *
from Admin import Admin
from Instructor import *
from method import isInsinDB


def showAdminFunc():
    print("1 : Add an instructor")
    print("2 : Delete an instructor")
    print("3 : Edit an instructor")
    print("4 : View all instructors")
    print("5 : Schedule an instructor")
    print("6 : register a student ")
    choice=int(input("input your choice : "))
    if(choice==1):
        Admin.addInstructor()
    elif(choice==2):
        Admin.deleteInstructor()

    elif(choice==3):
        Admin.editInstructor()
    elif(choice==4):
        Admin.viewInstructors()
    elif(choice==5):
        Admin.scheduleInstructor()
    elif (choice == 6):
        Admin.registerStudent()
    else:
        print("wrong choice")








def instructorFunc():

    name=input("input your Name instructor : ")
    res=isInsinDB(name)
    if(res==False):
        print("you are not registered..")

    else:
        ins = Instructor(res[0][0], res[0][1], res[0][2], res[0][3], res[0][4], "")
        ins.addLessonBooking()




root=Tk()

root.title("LOGIN SCREEN")
root.geometry("500x500")
root.resizable(False, False)

lblH=Label(root,text="DanceFeet",fg="blue", border=0, width=20,font=(30)).place(x=150,
                                                                                                                 y=50)
lblH2=Label(root,text="logging as :",fg="black", border=0, width=20,font=(20)).place(x=150,
                                                                                                                 y=100)

btnAdmin=Button(root,fg="white", bg="blue", border=0, width=20,command=showAdminFunc,text="Admin",relief=RIDGE,font=(20)).place(x=50,
                                                                                                                 y=200)
btnIns=Button(root,fg="white", bg="blue", border=0, width=20,command=instructorFunc,text="Instructor",relief=RIDGE,font=(20)).place(x=250,
                                                                                                                 y=200)

root.mainloop();






