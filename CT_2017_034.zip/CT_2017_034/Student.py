class Student:
    def __init__(self,studentid,firstnamen,lastname,email,gender,dateofBirth,contact,address,Style,maxRate):
        self.stId=studentid;
        self.firstName=firstnamen
        self.surName=lastname
        self.email=email
        self.gender=gender
        self.DoB=dateofBirth
        self.tpNo=contact
        self.address=address
        self.danceStyles=Style
        self.maxHrRate=maxRate
