from Student import *
from method import *
class Instructor:
    def __init__(self,name,gender,styles,tp,rte,availability):
        self.name=name
        self.gender=gender
        self.styles=styles
        self.tpNo=tp
        self.hrRate=rte
        self.availability=availability





    def LessonBooking(self):

        if(isInsinDB(self.name)):
            bookingNo=input("input booking no : ")

            addAbooking(self.name,bookingNo)
        else:
            print("you are not registered..")




